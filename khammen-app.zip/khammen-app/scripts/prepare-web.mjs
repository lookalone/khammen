// Builds www/ from game/index.html: proper document wrapper + fonts bundled offline.
import fs from "node:fs";
import path from "node:path";

const OUT = "www";
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(path.join(OUT, "fonts"), { recursive: true });

let html = fs.readFileSync("game/index.html", "utf8");

// fonts: copy the @fontsource packages so the game works with no internet
const FONTS = [
  ["lalezar", ["400.css"]],
  ["ibm-plex-sans-arabic", ["400.css", "600.css", "700.css"]],
];
let links = "";
for (const [pkg, sheets] of FONTS) {
  const src = path.join("node_modules", "@fontsource", pkg);
  if (!fs.existsSync(src)) { console.warn("font package missing:", pkg); continue; }
  fs.cpSync(src, path.join(OUT, "fonts", pkg), { recursive: true });
  for (const css of sheets) {
    const file = fs.existsSync(path.join(src, css)) ? css : "index.css";
    links += `<link rel="stylesheet" href="fonts/${pkg}/${file}">\n`;
  }
}
// drop the online Google Fonts links
html = html.replace(/<link[^>]*fonts\.(googleapis|gstatic)\.com[^>]*>\s*/g, "");

// meta + title belong in <head>
let head = "";
html = html.replace(/<meta\b[^>]*>\s*|<title>[^<]*<\/title>\s*/gi, (t) => { head += t.trim() + "\n"; return ""; });

if (!/^\s*<!doctype/i.test(html)) {
  html = `<!doctype html>
<html lang="ar">
<head>
<meta charset="utf-8">
<meta name="theme-color" content="#150e1f">
${head}${links}</head>
<body>
${html}
</body>
</html>
`;
} else {
  html = html.replace(/<\/head>/i, links + "</head>");
}
fs.writeFileSync(path.join(OUT, "index.html"), html);
console.log("www/index.html ready,", (html.length / 1024).toFixed(0), "KB");
