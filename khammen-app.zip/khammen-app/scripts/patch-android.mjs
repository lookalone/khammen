// Runs after `npx cap add android`: portrait only, full-screen (immersive), version number.
import fs from "node:fs";
import path from "node:path";

const cfg = JSON.parse(fs.readFileSync("capacitor.config.json", "utf8"));
const pkgPath = cfg.appId.replace(/\./g, "/");

// 1) lock to portrait
const manifest = "android/app/src/main/AndroidManifest.xml";
let m = fs.readFileSync(manifest, "utf8");
if (!m.includes("screenOrientation")) {
  m = m.replace(/(<activity\b[^>]*?android:name="\.MainActivity")/, '$1\n            android:screenOrientation="portrait"');
}
fs.writeFileSync(manifest, m);
if (!m.includes('android:screenOrientation="portrait"')) { console.error("could not lock orientation"); process.exit(1); }

// 2) immersive full-screen: hide status + navigation bars (swipe from the edge shows them for a moment)
const main = path.join("android/app/src/main/java", pkgPath, "MainActivity.java");
fs.writeFileSync(main, `package ${cfg.appId};

import android.os.Bundle;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideSystemBars();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        c.hide(WindowInsetsCompat.Type.systemBars());
        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }
}
`);

// 3) version: every GitHub build gets a higher number so it installs over the old one
const gradle = "android/app/build.gradle";
let g = fs.readFileSync(gradle, "utf8");
const run = parseInt(process.env.GITHUB_RUN_NUMBER || "1", 10);
g = g.replace(/versionCode\s+\d+/, `versionCode ${run}`).replace(/versionName\s+"[^"]*"/, `versionName "1.0.${run}"`);
fs.writeFileSync(gradle, g);
console.log("android patched: portrait, immersive, version 1.0." + run);
